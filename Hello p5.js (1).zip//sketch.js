var backgroundC = ('black');

function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(backgroundC);
  if (mouseY < windowHeight / 5) {
    backgroundC = ('orange');
  } else if (mouseY < 2 * windowHeight / 5) {
    backgroundC = ('red');
  } else if (mouseY < 3 * windowHeight / 5) {
    backgroundC = ('green');
  } else if (mouseY < 4 * windowHeight / 5) {
    backgroundC = ('purple');
  } else {
    backgroundC = ('yellow');
  }
}